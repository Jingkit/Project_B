﻿using System;
using System.Collections.Generic;

class Code
{
    public List<int> reservationCode { get; set; }
}
