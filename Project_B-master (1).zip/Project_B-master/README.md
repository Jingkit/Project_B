# Project_B

1. Login/Register account:
Here you can login or register an account .

2. Reserve table/Cancel reservation:
Here you can make or cancel a reservation.

3. Menu and dishes:
Here you can view the menu and the dishes. When in the current menu, press s, then the dish number for the dish detail of that dish or the letters v, h or g to sort by category.

4. Account:
Here you can add your personal information to your account so that you do not have to fill in the necessary information again when making a reservation. 
For this you need to first be logged into an account before you can access this page.

5. Admin:
Here you can access the admin functionalities: add dish, change dish and change week. The password for this page is ‘Admin’ (Capital sensitive).

6. Information about the restaurant:
Here you can find the information about the restaurant.

Note:
Our reservation system uses a 2 week schedule, when 1 week has passed, the admin needs to “change the week” to generate a new schedule for the new week. 
The schedule for next week will then turn into this week and next week will be empty and available to make a reservation.
