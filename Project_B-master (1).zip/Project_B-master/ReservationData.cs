﻿using System;

class ReservationData
{
    public Time Tuesday { get; set; }
    public Time Wednesday { get; set; }
    public Time Thursday { get; set; }
    public Time Friday { get; set; }
    public Time Saturday { get; set; }
    public Time Sunday { get; set; }

}
class Time
{
    public Table Four { get; set; }
    public Table Six { get; set; }
    public Table Eight { get; set; }
}
class Table
{
    public string Table1 { get; set; }
    public string Table2 { get; set; }
    public string Table3 { get; set; }
    public string Table4 { get; set; }
    public string Table5 { get; set; }
    public string Table6 { get; set; }
    public string Table7 { get; set; }
    public string Table8 { get; set; }
    public string Table9 { get; set; }
    public string Table10 { get; set; }
}
